package kingchatteam.com;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import com.github.nkzawa.socketio.client.IO;
import com.github.nkzawa.socketio.client.Socket;
import com.github.nkzawa.emitter.Emitter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity {

    private EditText _txt_username;
    private Button   _button_login,_button_chat;
    private ListView _list_user_connect, _lvChat;
    private ArrayList<String> _arrUserConnect;
    // Tạo kết nối tới server
    public Socket mSocket;
    {
        try {
            mSocket = IO.socket("http://192.168.100.5:3000");
        } catch (URISyntaxException e) {
            Log.e("Lỗi kết nối", "Lỗi: " + e.toString());

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        mSocket.connect();
        //Lấy kết qua từ server gửi về
        mSocket.on("server-gui-ket-qua-dangky", onNewMessage_userCallBack);
//        // Hiển thị danh sách user đã được đăng ký
//        mSocket.on("servar-gui-user-dangky", onNewMessage_DanhSachUserDangKy);

        //
        _txt_username = (EditText) findViewById(R.id.xml_username);
        _button_login = (Button) findViewById(R.id.xml_button_login);
//        _button_chat = (Button) findViewById(R.id.xml_button_chat);
//        _lvChat = (ListView) findViewById(R.id.xml_list_chat);
//      _list_user_connect = (ListView) findViewById(R.id.xml_list_user_connect);
      _button_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Gửi user về server
                mSocket.emit("client-gui-username", _txt_username.getText().toString());
            }
       });

//        _button_chat.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                mSocket.emit("client-gui-tin-chat", _txt_username.getText().toString());
//            }
//        });



    }

    // Lắng nghe thông tin từ phía server gửi về
    private Emitter.Listener onNewMessage_userCallBack = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    JSONObject data = (JSONObject) args[0];
                    String noidung;
                    String message;
                    try {
                        noidung = data.getString("noidung");
                      //  message = data.getString("message");
                        if(noidung == "true"){
                            Intent intent = new Intent(getApplicationContext(), MenuMainActivity.class);
                            startActivity(intent);
                            finish();
                            Toast.makeText(getBaseContext(), "Dang ky thanh cong!", Toast.LENGTH_SHORT).show();
                        }else{
                            Toast.makeText(getBaseContext(), "User da ton tai !", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        return;
                    }

//                    // add the message to view
//                    addMessage(username, message);
                }
            });
        }
    };
//
//    // Lắng nghe phía server gủi danh sách thành viên online về
//    private Emitter.Listener onNewMessage_DanhSachUserDangKy = new Emitter.Listener() {
//        @Override
//        public void call(final Object... args) {
//            runOnUiThread(new Runnable() {
//                @Override
//                public void run() {
//                    JSONObject data = (JSONObject) args[0];
//                    JSONArray _ArrayDanhSachUserDangKy;
//                    try {
//                        //Lấy danh sách user online
//                        _ArrayDanhSachUserDangKy = data.getJSONArray("DanhSachDangKy");
//                        //Lấy danh sách user đang online vào listview
//                        _arrUserConnect = new ArrayList<String>();
//                            for(int i =0; i < _ArrayDanhSachUserDangKy.length(); i++){
//                                _arrUserConnect.add(_ArrayDanhSachUserDangKy.get(i).toString());
//                            }
//                        ArrayAdapter stringArrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, _arrUserConnect);
//                        _list_user_connect.setAdapter(stringArrayAdapter);
//                        stringArrayAdapter.notifyDataSetInvalidated();
//                        //Toast.makeText(getApplicationContext(), Integer.toString(DanhSachOnline.length()), Toast.LENGTH_SHORT).show();
//                    } catch (JSONException e) {
//                        return;
//                    }
//
////                    // add the message to view
////                    addMessage(username, message);
//                }
//            });
//        }
//    };
//

}
