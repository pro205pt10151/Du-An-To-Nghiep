var express = require("express");
var app = express();
var server = require("http").createServer(app);
var io = require("socket.io").listen(server);
var fs = require("fs");
server.listen(process.env.PORT || 3000);

var mangUserName = [];
/*app.get("/", function(req, res){
	res.sendFile(__dirname + "/index.html");	
});*/
// Tạo kết nối 
io.sockets.on('connection', function (socket) {
	
	  console.log("Co nguoi dang ket noi :))");
	  //lắng nghe client gửi user về server
	  socket.on('client-gui-username', function (data){
		  console.log("Chao ban: " + data);
		  var _check_dang_ky = false;
		  if(mangUserName.indexOf(data) > -1){ // nếu trang mảng tồn tại user đăng ký thông báo
			  _check_dang_ky = false;
			  console.log("User: "+ data + " da duoc dang ky!");
		  }else{
			  mangUserName.push(data);
			  socket.un = data; // socket.un để biết ai đang chat
			  _check_dang_ky = true;
			  console.log("Dang ky thanh cong!");
			 //Gửi những Username đang online
			  io.sockets.emit("servar-gui-user-dangky", {DanhSachDangKy: mangUserName}); // đưa đanh sách đã đăng ký vào
			  
		  }
		     
			 //Gủi thông tin đăng ký về server
		     socket.emit('server-gui-ket-qua-dangky', {noidung: _check_dang_ky});
		  
	  });
	  //Lắng nghe client gửi tin nhắn về
	  socket.on('client-gui-tin-chat', function (data_chat){
		//  console.log(socket.un + ": " + data_chat);
		  io.sockets.emit('server-gui-tra-tin-chat', {data_tinchat: socket.un + ": " +data_chat});
	  });
});